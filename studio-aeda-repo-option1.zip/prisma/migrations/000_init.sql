-- Enable pgvector
CREATE EXTENSION IF NOT EXISTS vector;

-- Example: table managed by Prisma will create schema, but here is a sample index you can apply later:
-- CREATE INDEX IF NOT EXISTS vectordoc_embedding_idx
--   ON "VectorDoc" USING ivfflat (embedding vector_l2_ops) WITH (lists = 100);
