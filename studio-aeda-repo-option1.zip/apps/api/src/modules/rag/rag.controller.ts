import { Controller, Post, Body } from '@nestjs/common';
import { RagService } from './rag.service';

@Controller('rag')
export class RagController {
  constructor(private readonly rag: RagService) {}

  @Post('ingest')
  async ingest(@Body() body: any) {
    return this.rag.ingest(body);
  }

  @Post('search')
  async search(@Body() body: any) {
    return this.rag.search(body.query, body.limit || 5);
  }
}
