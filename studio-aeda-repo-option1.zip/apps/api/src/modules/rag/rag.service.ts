import { Injectable } from '@nestjs/common';

/**
 * Stub de RAG: conecte com Postgres/pgvector e seu serviço de embeddings.
 */
@Injectable()
export class RagService {
  async ingest({ text, metadata }: { text: string; metadata?: Record<string, any> }) {
    // 1) gerar embedding
    // 2) salvar em VectorDoc (Prisma)
    return { ok: true, inserted: 1, metadata };
  }

  async search(query: string, limit = 5) {
    // 1) gerar embedding do query
    // 2) buscar por similaridade em VectorDoc
    // 3) retornar top-k
    return { ok: true, results: [], limit };
  }
}
