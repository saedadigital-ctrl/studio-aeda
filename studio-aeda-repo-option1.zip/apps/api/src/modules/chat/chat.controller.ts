import { Controller, Post, Body, Sse } from '@nestjs/common';
import { ChatService } from './chat.service';
import { Observable } from 'rxjs';

@Controller('chat')
export class ChatController {
  constructor(private readonly chat: ChatService) {}

  @Post()
  async handle(@Body() body: any) {
    const { messages, tenantId } = body;
    return this.chat.generate(messages, tenantId);
  }

  @Sse('stream')
  stream(): Observable<MessageEvent> {
    return this.chat.stream();
  }
}
