import axios from 'axios';
import { Injectable } from '@nestjs/common';

const LLM_BASE_URL = process.env.LLM_BASE_URL || 'http://localhost:8000';
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

@Injectable()
export class ChatService {
  async generate(messages: any[], tenantId?: string) {
    // Simple router: try local LLM (vLLM/TGI). If fails, fallback to OpenAI.
    try {
      const r = await axios.post(`${LLM_BASE_URL}/v1/chat/completions`, {
        model: process.env.LLM_MODEL_ID,
        messages,
        temperature: 0.4,
        stream: false
      }, { timeout: 4000 });
      return { provider: 'local', ...r.data };
    } catch (e) {
      if (!OPENAI_API_KEY) throw e;
      const r = await axios.post(`https://api.openai.com/v1/chat/completions`, {
        model: 'gpt-4o-mini',
        messages,
        temperature: 0.4,
        stream: false
      }, { headers: { Authorization: `Bearer ${OPENAI_API_KEY}` }});
      return { provider: 'openai', ...r.data };
    }
  }

  stream() {
    // Stub SSE stream — implement with NestJS RxJS + axios streaming
    return new (require('rxjs')).Observable((subscriber) => {
      subscriber.next({ data: 'streaming stub' });
      subscriber.complete();
    });
  }
}
