import { Injectable } from '@nestjs/common';

@Injectable()
export class WaService {
  processInbound(body: any, headers: any) {
    // TODO: validar assinatura se necessário
    const normalized = { from: 'whatsapp:+55...', message: 'payload', tenantId: 'default' };
    return { ok: true, normalized };
  }
}
