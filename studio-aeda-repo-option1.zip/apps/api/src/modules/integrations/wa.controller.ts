import { Controller, Post, Body, Headers } from '@nestjs/common';
import { WaService } from './wa.service';

@Controller('wa')
export class WaController {
  constructor(private readonly wa: WaService) {}

  @Post('inbound')
  inbound(@Body() body: any, @Headers() headers: any) {
    // Normalize payload 360dialog/Twilio => { from, message, tenantId }
    return this.wa.processInbound(body, headers);
  }
}
