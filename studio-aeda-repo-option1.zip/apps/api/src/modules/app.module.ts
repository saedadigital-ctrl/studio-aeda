import { Module } from '@nestjs/common';
import { ChatModule } from './chat/chat.module';
import { RagModule } from './rag/rag.module';
import { IntegrationsModule } from './integrations/integrations.module';
import { AdminModule } from './admin/admin.module';

@Module({
  imports: [ChatModule, RagModule, IntegrationsModule, AdminModule],
})
export class AppModule {}
