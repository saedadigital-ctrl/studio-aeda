'use client';
import { useState } from 'react';

export default function Home() {
  const [messages, setMessages] = useState<{role:'user'|'assistant', content:string}[]>([]);
  const [input, setInput] = useState('');

  async function send() {
    const body = { messages: [{ role: 'system', content: 'Você é um agente imobiliário útil.' }, ...messages, { role: 'user', content: input }], tenantId: 'default' };
    const r = await fetch(process.env.NEXT_PUBLIC_API_BASE + '/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const data = await r.json();
    const content = data.choices?.[0]?.message?.content || JSON.stringify(data);
    setMessages(m => [...m, { role: 'user', content: input }, { role: 'assistant', content }]);
    setInput('');
  }

  return (
    <main className="max-w-3xl mx-auto p-6">
      <h1 className="text-2xl font-semibold mb-4">Studio AEDA – Chat</h1>
      <div className="border rounded-lg p-4 bg-white space-y-3">
        {messages.map((m, i) => (
          <div key={i} className={m.role === 'user' ? 'text-right' : 'text-left'}>
            <span className="inline-block rounded px-3 py-2 border bg-neutral-100">{m.content}</span>
          </div>
        ))}
      </div>
      <div className="mt-4 flex gap-2">
        <input className="flex-1 border rounded px-3 py-2" value={input} onChange={e=>setInput(e.target.value)} placeholder="Digite sua mensagem..." />
        <button onClick={send} className="px-4 py-2 rounded bg-black text-white">Enviar</button>
      </div>
    </main>
  );
}
