export const metadata = { title: 'Studio AEDA – Chat', description: 'Chat com RAG' };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-br">
      <body className="min-h-screen bg-neutral-50">{children}</body>
    </html>
  );
}
