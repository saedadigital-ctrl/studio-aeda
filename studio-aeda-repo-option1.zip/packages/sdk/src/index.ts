export type ChatMessage = { role: 'system'|'user'|'assistant'; content: string };

export async function chat(messages: ChatMessage[], opts?: { apiBase?: string, tenantId?: string }) {
  const apiBase = opts?.apiBase || 'http://localhost:3001';
  const r = await fetch(`${apiBase}/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages, tenantId: opts?.tenantId || 'default' })
  });
  return await r.json();
}
