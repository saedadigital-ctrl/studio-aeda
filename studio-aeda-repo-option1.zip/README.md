# Studio AEDA – Monorepo Base (Imobiliário)

Stack: **Next.js (web)** + **NestJS (API)** + **PostgreSQL + pgvector (RAG)** + **Redis/BullMQ** + **Docker/K8s**.

> Pronto para: chat com RAG, WhatsApp webhook (360dialog/Twilio), funil imobiliário, multi-tenant e métricas.

## Pastas
- `apps/web` — Front-end Next.js (chat + catálogo)
- `apps/api` — API NestJS (chat, rag, integrações, admin)
- `packages/sdk` — SDK TypeScript compartilhado (tipos, cliente)
- `prisma` — schema e migrações
- `deploy` — Dockerfiles e K8s

## Rodando rápido (dev)
1) Crie `.env` na raiz com base em `.env.example`  
2) Suba dependências: `docker compose up -d postgres redis`  
3) Instale deps: `pnpm i` (ou `npm i`)  
4) Migre: `pnpm prisma migrate dev`  
5) Inicie: `pnpm -w run dev` (API + WEB)

## Serviços (portas padrão)
- API NestJS: `http://localhost:3001`
- Web Next.js: `http://localhost:3000`
- Postgres: `localhost:5432`
- Redis: `localhost:6379`

## Observabilidade (stub)
Prometheus/Grafana/OTel prontos para estender em `deploy/observability`.

## Licença
MIT


---

## Deploy – Opção 1 (Vercel + Render + Neon + Upstash + 360dialog)

### 1) Banco (Neon ou Supabase)
- Crie um Postgres e copie a `DATABASE_URL`.
- Se usar Supabase, ative a extensão: `CREATE EXTENSION IF NOT EXISTS vector;`

### 2) Redis (Upstash)
- Crie uma instância e copie `REDIS_URL` (formato `redis://...`).

### 3) API (Render)
- Conecte o repositório e escolha a pasta `deploy/api` (Dockerfile).
- Defina as VARs:
  - `DATABASE_URL`
  - `REDIS_URL`
  - `OPENAI_API_KEY` (opcional, fallback)
  - `LLM_BASE_URL` (se tiver endpoint do seu vLLM; opcional)
  - `LLM_MODEL_ID` (se usar LLM próprio)
- Comando de inicialização: **Render detecta Docker** (nenhum build/start custom necessários).
- Pós-deploy (opcional via Shell da Render): `pnpm prisma migrate deploy`

### 4) Web (Vercel)
- Importe o monorepo e selecione `apps/web`.
- Variáveis no projeto Web:
  - `NEXT_PUBLIC_API_BASE=https://SEU_SERVICO_DA_RENDER.onrender.com`
- Framework preset: **Next.js**

### 5) WhatsApp (360dialog)
- Gere API Key e configure o webhook para: `https://SEU_SERVICO_DA_RENDER.onrender.com/wa/inbound`

### 6) Produção
- Verifique saúde da API: `GET https://SEU_SERVICO_DA_RENDER.onrender.com/admin/health`
- Abra o Web: `https://SEU_DOMINIO_VERCEL.vercel.app`

